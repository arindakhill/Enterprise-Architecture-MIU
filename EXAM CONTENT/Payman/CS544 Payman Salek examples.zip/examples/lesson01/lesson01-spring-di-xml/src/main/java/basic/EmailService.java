package basic;

public class EmailService {
    public void sendEmail(){
        System.out.println("sendEmail");
    }
}
