package basic;

public class CustomerService {
	public void sayHello(){
		System.out.println("Hello from CustomerService");
	}

}
