package demo;

public interface IAccountService {
    public void addAccount(String accountNumber, Customer customer);
}
