package demo;

public interface CustomerService {
    void addCustomer();
}
