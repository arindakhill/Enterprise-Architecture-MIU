package demo;

public interface EmailService {
    void sendEmail();
}
