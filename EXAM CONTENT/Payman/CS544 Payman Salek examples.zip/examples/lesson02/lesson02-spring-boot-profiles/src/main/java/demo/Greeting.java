package demo;

public interface Greeting {
    public String getGreeting();
}
