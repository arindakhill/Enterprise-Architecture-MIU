package lab6b;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab6bApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab6bApplication.class, args);
	}

}
