package customers;

public interface IProductService {
	void addProduct(String description, Double price, String email);
}
